from utils import *
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn.impute import KNNImputer
from sklearn.tree import DecisionTreeClassifier
np.random.seed(42)
#################################################################################
#use classification tree as base model
def base_Model(train_data,valid_data,c,l):

    train = pd.DataFrame(train_data)
    val=pd.DataFrame(valid_data)
    X_val = val.drop("is_correct", axis=1)
    sample_size = len(train)
    #bootstap train data
    indices = np.random.choice(range(len(train)), size=sample_size, replace=True)
    train_bootstrap = train.iloc[indices]
    X_train_bootstrap = train_bootstrap[['question_id', 'user_id']].values
    #standardize data
    standardized_X_train_bootstrap = scaler.fit_transform(X_train_bootstrap)
    y_train_bootstrap = train_bootstrap['is_correct'].values
    standardized_X_val = scaler.fit_transform(X_val)
    clf = DecisionTreeClassifier(random_state=42,criterion=c,min_samples_leaf=l)
    clf.fit(standardized_X_train_bootstrap, y_train_bootstrap)
    y_pred = clf.predict(standardized_X_val)
    return y_pred
#base model for phase1 (no standardization)
def base_Model_1st(train_data,valid_data,c,l):

    train = pd.DataFrame(train_data)
    val=pd.DataFrame(valid_data)
    X_val = val.drop("is_correct", axis=1)
    sample_size = len(train)
    indices = np.random.choice(range(len(train)), size=sample_size, replace=True)
    train_bootstrap = train.iloc[indices]
    X_train_bootstrap = train_bootstrap[['question_id', 'user_id']].values
    y_train_bootstrap = train_bootstrap['is_correct'].values
    clf = DecisionTreeClassifier(random_state=42,criterion=c,min_samples_leaf=l)
    clf.fit(X_train_bootstrap, y_train_bootstrap)
    y_pred = clf.predict(X_val)
    return y_pred
# predict output using voting between models
def pred_ensemble(pred1,pred2,pred3,pred4,pred5,v):
    s=np.sum(v)
    #calculate wage of each models vote
    l=[]
    for i in v :
        l.append(i/s)
    t=[]
    for i in range(len(pred1)):
        temp = ((pred1[i]*l[0])+(pred2[i]*l[1])+(pred3[i]*l[2])+(pred4[i]*l[3])+(pred5[i]*l[4]))
        if (temp>0.5) :
            t.append(1)
        else :
            t.append(0)

    return t
#prediction function of phase1 (uniform voting)
def pred_ensemble_1st(pred1,pred2,pred3,v):
    s=np.sum(v)
    l=[]
    for i in v :
        l.append(i/s)
    t=[]
    for i in range(len(pred1)):
        temp = ((pred1[i]*l[0])+(pred2[i]*l[1])+(pred3[i]*l[2]))
        if (temp>0.5) :
            t.append(1)
        else :
            t.append(0)

    return t
##########################################################################
scaler = StandardScaler()
sparse_matrix = load_train_sparse("../data").toarray()
val_data = load_valid_csv("../data")
train_data = load_train_csv("../data")
train = pd.DataFrame(train_data)
X_train=train.drop("is_correct", axis=1)
standardized_X_train = scaler.fit_transform(X_train)

val = pd.DataFrame(val_data)
X_val = val.drop("is_correct", axis=1)
standardized_X_val = scaler.fit_transform(X_val)
y_train=train["is_correct"]
y_val=val["is_correct"]
acc_val = []

#train 5 base models
prediction_model_1 = base_Model(train_data,val_data,"gini",1)
prediction_model_2 = base_Model(train_data,val_data,"gini",2)
prediction_model_3 = base_Model(train_data,val_data,"gini",4)
prediction_model_4 = base_Model(train_data,val_data, "entropy", 2)
prediction_model_5 = base_Model(train_data,val_data, "log_loss", 3)
#performance of each base model on validation set
v=[evaluate(val_data,prediction_model_1),evaluate(val_data,prediction_model_2),evaluate(val_data,prediction_model_3),
   evaluate(val_data,prediction_model_4),evaluate(val_data,prediction_model_5)]

voting_output=pred_ensemble(prediction_model_1,prediction_model_2,prediction_model_3,prediction_model_4,prediction_model_5,v)
print('val acc phase 2 model : ',evaluate(val_data,voting_output))

#phase 1 base models prediction
prediction_model_3_1st = base_Model_1st(train_data,val_data,"gini",4)
prediction_model_4_1st = base_Model_1st(train_data,val_data, "entropy", 2)
prediction_model_5_1st = base_Model_1st(train_data,val_data, "log_loss", 3)

v_prime=[1,1,1]
temp=evaluate(val_data,pred_ensemble_1st(prediction_model_3_1st,prediction_model_4_1st,prediction_model_5_1st,v_prime))
print('val acc phase 1 model : ',temp)