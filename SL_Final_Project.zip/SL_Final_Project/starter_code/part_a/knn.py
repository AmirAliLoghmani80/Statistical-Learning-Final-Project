from sklearn.impute import KNNImputer
from utils import *
import os
#####################################################################
# TODO:                                                             #
# Import packages you need here                                     #
import matplotlib.pyplot as plt
import numpy as np
np.random.seed(42)

#####################################################################
#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################  

def knn_impute_by_user(matrix, valid_data, k):
    """ Fill in the missing values using k-Nearest Neighbors based on
    student similarity. Return the accuracy on valid_data.

    See https://scikit-learn.org/stable/modules/generated/sklearn.
    impute.KNNImputer.html for details.

    :param matrix: 2D sparse matrix
    :param valid_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param k: int
    :return: float
    """
    #####################################################################
    # TODO:                                                             #
    # Implement the function as described in the docstring.             #
    #####################################################################
    imputer = KNNImputer(n_neighbors=k)
    imputer.fit(matrix)
    completed_mat = imputer.transform(matrix)
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################    
    acc = sparse_matrix_evaluate(valid_data, completed_mat)
    print("Validation Accuracy: {}".format(acc))
    return acc


def knn_impute_by_item(matrix, valid_data, k):
    """ Fill in the missing values using k-Nearest Neighbors based on
    question similarity. Return the accuracy on valid_data.

    :param matrix: 2D sparse matrix
    :param valid_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param k: int
    :return: float
    """
    #####################################################################
    # TODO:                                                             #
    # Implement the function as described in the docstring.             #
    #####################################################################
    imputer = KNNImputer(n_neighbors=k)
    #transpose matrix to use items for knn algorithm
    imputer.fit(matrix.transpose())
    completed_mat = imputer.transform(matrix.transpose())
    completed_mat=completed_mat.transpose()
    acc = sparse_matrix_evaluate(valid_data, completed_mat)
    print("Validation Accuracy: {}".format(acc))

    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return acc


def knn_main():
    sparse_matrix = load_train_sparse("../data").toarray()
    val_data = load_valid_csv("../data")
    test_data = load_public_test_csv("../data")

    print("Sparse matrix:")
    print(sparse_matrix)
    print("Shape of sparse matrix:")
    print(sparse_matrix.shape)

    #####################################################################
    # Part B&C:                                                         #
    # Compute the validation accuracy for each k. Then pick k* with     #
    # the best performance and report the test accuracy with the        #
    # chosen k*. do all these using knn_impute_by_user().                                                      #
    K=[1,6,11,16,21,26]
    acc_val_user=[]
    for k in K:
        acc_val_user.append(knn_impute_by_user(sparse_matrix, val_data, k))
    plt.plot(K,acc_val_user)
    plt.xlabel('k')
    plt.ylabel('accuracy')
    plt.title('user_based')
    plt.savefig('../plots/knn/userBased_acc.png')
    best_k_user=K[acc_val_user.index(max(acc_val_user))]
    print('k* : ',best_k_user,'\n','validation accuracy for k* users metric : ',max(acc_val_user))

    #####################################################################
    pass
    user_best_k:float = best_k_user                    # :float means that this variable should be a float number
    user_test_acc:float = knn_impute_by_user(sparse_matrix,test_data,best_k_user)
    user_valid_acc:list = acc_val_user
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################

    #####################################################################
    # Part D:                                                           #
    # Compute the validation accuracy for each k. Then pick k* with     #
    # the best performance and report the test accuracy with the        #
    # chosen k*. do all these using knn_impute_by_item().                                                        #
    #####################################################################
    acc_val_item = []
    for k in K:
        acc_val_item.append(knn_impute_by_item(sparse_matrix, val_data, k))
    plt.plot(K, acc_val_item)
    plt.xlabel('k')
    plt.ylabel('accuracy')
    plt.title('item_based')
    plt.savefig('../plots/knn/itemBased_acc.png')
    best_k_item = K[acc_val_item.index(max(acc_val_item))]
    print('k* : ', best_k_item, '\n', 'validation accuracy for k* item metric: ', max(acc_val_item))

    pass
    question_best_k:float = best_k_item
    question_test_acc:float = knn_impute_by_item(sparse_matrix,test_data,best_k_item)
    question_valid_acc:list = acc_val_item
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################

    results = {
    'user_best_k':user_best_k,
    'user_test_acc':user_test_acc,
    'user_valid_accs':user_valid_acc,
    'question_best_k':question_best_k,
    'question_test_acc':question_test_acc,
    'question_valid_acc':question_valid_acc,
    }
    
    
    return results

if __name__ == "__main__":
    knn_main()
