import numpy as np
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
#####################################################################
# TODO:                                                             #                                                          
# Import packages you need here                                     #
#####################################################################
from sklearn.impute import KNNImputer
from utils import *
np.random.seed(42)


#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################  




#####################################################################
# Define and implement functions here                               #
#####################################################################
#use classification tree as base model
def base_Model(train_data,valid_data,c,l):

    train = pd.DataFrame(train_data)
    val=pd.DataFrame(valid_data)
    X_val = val.drop("is_correct", axis=1)
    sample_size = len(train)
    #bootstrap data
    indices = np.random.choice(range(len(train)), size=sample_size, replace=True)
    train_bootstrap = train.iloc[indices]
    X_train_bootstrap = train_bootstrap[['question_id', 'user_id']].values
    y_train_bootstrap = train_bootstrap['is_correct'].values

    clf = DecisionTreeClassifier(random_state=42,criterion=c,min_samples_leaf=l)
    clf.fit(X_train_bootstrap, y_train_bootstrap)
    y_pred = clf.predict(X_val)
    return y_pred

def base_Model_2nd_type(train_data,valid_data,c,l):

    train = pd.DataFrame(train_data)
    val=pd.DataFrame(valid_data)
    sample_size = len(train)
    #bootstrap data
    indices = np.random.choice(range(len(train)), size=sample_size, replace=True)
    train_bootstrap = train.iloc[indices]
    X_train_bootstrap = train_bootstrap[['question_id', 'user_id']].values
    y_train_bootstrap = train_bootstrap['is_correct'].values

    clf = DecisionTreeClassifier(random_state=42,criterion=c,min_samples_leaf=l)
    clf.fit(X_train_bootstrap, y_train_bootstrap)
    y_pred = clf.predict(valid_data)
    return y_pred
#####################################################################
#                       END OF YOUR CODE                            #
##################################################################### 
#predict output using all models predictions
def acc_ensemble(pred1,pred2,pred3):
    t=[]
    for i in range(len(pred1)):
        temp = (pred1[i]+pred2[i]+pred3[i])
        if (temp>1) :
            t.append(1)
        else :
            t.append(0)

    return t



def ensemble_main():

    #####################################################################
    # Compute the finall validation and test accuracy                   #
    #####################################################################
    sparse_matrix = load_train_sparse("../data").toarray()
    train_data = load_train_csv("../data")
    val_data = load_valid_csv("../data")
    test_data = load_public_test_csv("../data")


    m1 = base_Model(train_data,val_data,"gini",4)
    m2 = base_Model(train_data,val_data, "entropy", 2)
    m3 = base_Model(train_data,val_data, "log_loss", 3)
    b=acc_ensemble(list(m1),list(m2),list(m3))

    #fill nan values of sparse matrix using models
    indices = np.where(np.isnan(sparse_matrix))
    nan_indices = np.column_stack(indices)
    predicted_values_m1 = list(base_Model_2nd_type(train_data,nan_indices,"gini",4))
    predicted_values_m2 = list(base_Model_2nd_type(train_data,nan_indices,"entropy",2))
    predicted_values_m3 = list(base_Model_2nd_type(train_data,nan_indices,"log_loss",3))


    output1=sparse_matrix
    output1[indices]=predicted_values_m1
    output2 = sparse_matrix
    output2[indices] = predicted_values_m2
    output3 = sparse_matrix
    output3[indices] = predicted_values_m3

    val_acc_ensemble:float =evaluate(val_data,b)
    #accuaracy on test calculations
    m1 = base_Model(train_data,test_data,"gini",4)
    m2 = base_Model(train_data,test_data, "entropy", 2)
    m3 = base_Model(train_data,test_data, "log_loss", 3)
    b=acc_ensemble(list(m1),list(m2),list(m3))
    test_acc_ensemble:float = evaluate(test_data,b)

    method1_output_matrix:np.array = output1
    method2_output_matrix:np.array = output2
    method3_output_matrix:np.array = output3
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################

    results={
    'val_acc_ensemble':val_acc_ensemble,
    'test_acc_ensemble':test_acc_ensemble,
    'method1_output_matrix':method1_output_matrix,
    'method2_output_matrix':method2_output_matrix,
    'method3_output_matrix':method3_output_matrix
    }
    ev1=evaluate(val_data,list(m1))
    ev2 = evaluate(val_data, list(m2))
    ev3 = evaluate(val_data, list(m3))
    print('model 1 output',ev1,'\n','model 2 output',ev2,'\n'
          ,'model 3 output',ev3,'\n','ensemble output : ',val_acc_ensemble)
    return results


if __name__ == "__main__":
    ensemble_main()

