from utils import *
from scipy.linalg import sqrtm
from sklearn.impute import KNNImputer
import numpy as np
import matplotlib.pyplot as plt
np.random.seed(42)


def svd_reconstruct(matrix, k):

    """ Given the matrix, perform singular value decomposition
    to reconstruct the matrix.

    :param matrix: 2D sparse matrix
    :param k: int
    :return: 2D matrix
    """
    # First, you need to fill in the missing values (NaN) to perform SVD.
    imputer = KNNImputer(n_neighbors=11)
    imputer.fit(matrix)
    completed_mat = imputer.transform(matrix)
    #####################################################################
    # TODO:                                                             #
    # Part A:                                                           #
    # Implement the function as described in the docstring.             #
    #####################################################################
    U, S, Vt = np.linalg.svd(completed_mat)
    reconst_matrix =U[:, :k] @ np.diag(S[:k]) @ Vt[:k, :]

    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return np.array(reconst_matrix)


def squared_error_loss(data, u, z):
    """ Return the squared-error-loss given the data.
    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param u: 2D matrix
    :param z: 2D matrix
    :return: float
    """
    loss = 0
    for i, q in enumerate(data["question_id"]):
        loss += (data["is_correct"][i]
                 - np.sum(u[data["user_id"][i]] * z[q])) ** 2.
    return 0.5 * loss


def update_u_z(train_data, lr, u, z):
    """ Return the updated U and Z after applying
    stochastic gradient descent for matrix completion.

    :param train_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param lr: float
    :param u: 2D matrix
    :param z: 2D matrix
    :return: (u, z)
    """
    #####################################################################
    # TODO:                                                             #
    # Part C:                                                           #
    # Implement the function as described in the docstring.             #
    #####################################################################
    # Randomly select a pair (user_id, question_id).
    i = \
        np.random.choice(len(train_data["question_id"]), 1)[0]

    c = train_data["is_correct"][i]
    n = train_data["user_id"][i]
    q = train_data["question_id"][i]
    #update u and z using random sample
    u[n, :] = u[n, :] + lr * (c - np.dot(u[n, :], z[q, :])) * z[q,:]
    z[q, :] = z[q, :] + lr * (c - np.dot(u[n, :], z[q, :])) * u[n, :]


    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return u, z


def als(train_data, k, lr, num_iteration):
    """ Performs ALS algorithm. Return reconstructed matrix.

    :param train_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param k: int
    :param lr: float
    :param num_iteration: int
    :return: 2D reconstructed Matrix.
    """
    # Initialize u and z
    u = np.random.uniform(low=0, high=1 / np.sqrt(k),
                          size=(len(set(train_data["user_id"])), k))
    z = np.random.uniform(low=0, high=1 / np.sqrt(k),
                          size=(len(set(train_data["question_id"])), k))

    #####################################################################
    # TODO:                                                             #
    # Part C:                                                           #
    # Implement the function as described in the docstring.             #
    #####################################################################
    for i in range(num_iteration):
        u , z = update_u_z(train_data, lr, u, z)
    mat = np.dot(u, z.T)
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return mat,u,z


def matrix_factorization_main():
    import matplotlib.pyplot as plt

    train_matrix = load_train_sparse("../data").toarray()
    train_data = load_train_csv("../data")
    val_data = load_valid_csv("../data")
    test_data = load_public_test_csv("../data")

    #####################################################################
    # TODO:                                                             #
    # Part A:                                                           #
    # (SVD) Try out at least 5 different k and select the best k        #
    # using the validation set.                                         #
    #####################################################################
    svd_eval=[]
    l=[5,20,50,100,200]
    for i in l:
        svd_eval.append(sparse_matrix_evaluate(val_data,svd_reconstruct(train_matrix,i), threshold=0.5))
    print(svd_eval)


    best_k_svd:int=l[svd_eval.index(max(svd_eval))]
    best_val_acc_svd:float=max(svd_eval)
    print('best k for svd reconstruction (choices : k=5 20 50 100 200) : ',best_k_svd)
    print('best accuracy : ',best_val_acc_svd)
    test_acc_svd:float=sparse_matrix_evaluate(test_data,svd_reconstruct(train_matrix,l))
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################

    #####################################################################
    # TODO:                                                             #
    # Part D and E:                                                     #
    # (ALS) Try out at least 5 different k and select the best k        #
    # using the validation set.                                         #
    als_eval = []
    lr=0.001
    num_iteration=10000
    for i in l:
        mat,u,z = als(train_data,i,lr,num_iteration)
        als_eval.append(squared_error_loss(val_data, u, z))


    #####################################################################
    pass
    # Results of part D
    best_k_als:int=l[als_eval.index(min(als_eval))]
    mat, u, z = als(train_data, best_k_als, lr, 1000000)
    best_val_acc_als:float=sparse_matrix_evaluate(val_data,mat)
    print('best k for als (choices : 5 20 50 100 200) : ',best_k_als,'\n','best accuracy als : ',best_val_acc_als)

    # Results of part E
    als_error_iterration_train=[]
    als_error_iterration_validation=[]
    j=[]
    for i in range(100):
        j.append((i+1)*1000)
        mat, u, z = als(train_data, best_k_als, lr, 1000*(i+1))
        als_error_iterration_train.append(squared_error_loss(train_data,u,z))
        als_error_iterration_validation.append(squared_error_loss(val_data,u,z))
    print(als_error_iterration_train)

    plt.plot(j,als_error_iterration_train)
    plt.plot(j,als_error_iterration_validation)
    plt.legend(["train_data", "val_data"], loc="lower right")
    plt.xlabel('iterations')
    plt.ylabel('error')




    # Save the line chart
    import matplotlib.pyplot as plt
    plt.savefig('../plots/matrix_factorization/part_e.png')

    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    results={
    'best_k_svd':best_k_svd,
    'test_acc_svd':test_acc_svd,
    'best_val_acc_svd':best_val_acc_svd,
    'best_val_acc_als':best_val_acc_als,
    'best_k_als':best_k_als

    }

    return results

if __name__ == "__main__":

    matrix_factorization_main()
